import gensim
import json
import os
from gensim.parsing.preprocessing import remove_stopwords
from spacy.tokenizer import Tokenizer
from spacy.lang.en import English
import numpy as np
import subprocess
from subprocess import SubprocessError
from xml.dom import minidom
import xml.etree.ElementTree as ET
import re
import linecache
import errno
from sklearn.metrics.pairwise import cosine_similarity as cs
import networkx as nx
import matplotlib.pyplot as plt
import operator
import math
import itertools
from gensim.parsing.porter import PorterStemmer
import csv
import multiprocessing as mp
from multiprocessing import Manager
from networkx.readwrite import json_graph
import concurrent.futures
import threading
import pickle

# directory where marco passages are located
MARCO_DIR = "data/marco_ids/"

punctuation = ['.', ';', ':', ',', '!', '?']
not_wanted = ['&', '%', '+', '/', '_', '-', '(', ')', '$', "\n", "="]

nlp = English()

# prox3_dict is used for counting each bi-gram
prox3_dict = dict()
word_freq = dict()

# create an empty undirected graph by None parameter
G = nx.Graph()

node_lock = threading.Lock()
prox3_lock = threading.Lock()
word_freq_lock = threading.Lock()

COOC_WINDOW = 3


def processFiles(fname):  # deal with the segments in the dataset
    with open(os.path.join(MARCO_DIR, fname), 'r') as f:
        paragraph = f.read()

    doc = nlp(''.join(paragraph))
    # get token: 1. make sure all chars are English letters, 2. remove stop words,
    # 3. remove punctuation, 4. remove other symbols
    tokens = list([token.text.lower() for token in doc if
                   token.text.isalpha() and not token.is_stop and not token.text in punctuation and not token.text in not_wanted])
    # remaining tokens are only meaningful words
    # store frequency of two words appearing together in a context window of size 3
    res_added3 = []  # res_added3 is used to make sure whether a bi-gram is existed
    # prox3_dict is for counting

    prox3_lock.acquire()  # acquire resource so that others will not use it
    try:
        for i in range(len(tokens)):  # traverse the whole string
            # COOC_WINDOW is 3
            if i >= (len(tokens) - COOC_WINDOW):
                # dealing with the last three words
                upper_3 = len(tokens)
            else:
                # dealing with the others
                upper_3 = i + COOC_WINDOW + 1
            for j in range(i + 1, upper_3):  # traverse in one window

                if tokens[j] != tokens[i]:  # maybe useless
                    if tokens[i] < tokens[j]:  # put the text smaller in front of the bigger to create a bi-gram
                        if not str(tokens[i] + "_" + tokens[j]) in res_added3:
                            if str(tokens[i] + "_" + tokens[j]) in prox3_dict.keys():
                                prox3_dict[str(tokens[i] + "_" + tokens[j])] += 1  # count the number of each bi-gram
                            else:
                                prox3_dict[str(tokens[i] + "_" + tokens[j])] = 1
                            res_added3.append(str(tokens[i] + "_" + tokens[j]))
                    else:
                        if not str(tokens[j] + "_" + tokens[i]) in res_added3:
                            if str(tokens[j] + "_" + tokens[i]) in prox3_dict.keys():
                                prox3_dict[str(tokens[j] + "_" + tokens[i])] += 1
                            else:
                                prox3_dict[str(tokens[j] + "_" + tokens[i])] = 1
                            res_added3.append(str(tokens[j] + "_" + tokens[i]))

        # what are bi-grams used for?

    finally:
        prox3_lock.release()

    # add words as node in the graph
    node_lock.acquire()
    try:
        for token in set(tokens):
            G.add_node(token)  # different nodes represent different words
    finally:
        node_lock.release()

    # count how many times word appear in the corpus
    word_freq_lock.acquire()
    try:
        for token in set(tokens):
            if token in word_freq.keys():
                word_freq[token] += 1
            else:
                word_freq[token] = 1
    finally:
        word_freq_lock.release()


# end for the processFiles function


with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    # map(function, argus)
    executor.map(processFiles, os.listdir(MARCO_DIR))

# store frequency dictionary for proximity 3 for later usage
with open('data/graph_data/prox_3.pickle', 'wb') as handle:
    pickle.dump(prox3_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)

# number of passages in marco corpus
# nbr_docs = 8635155  # need to be changed for the smaller dataset
nbr_docs = 100000  # need to be changed for the smaller dataset
# add edges to graph and get the weight of each edge (edges are the pmi values between two words)
leng = len(prox3_dict.keys())
for key in prox3_dict.keys():
    leng -= 1
    print(leng)
    t1 = key.split("_")[0]
    t2 = key.split("_")[1]
    prox3_prob = prox3_dict[key] / nbr_docs
    # calculate the frequency each token appears in all docs
    t1_prob = word_freq[t1] / nbr_docs
    t2_prob = word_freq[t2] / nbr_docs
    val = prox3_prob / (t1_prob * t2_prob)
    pmi = math.log(val, 2)
    G.add_edge(t1, t2, weight=pmi)

# store created graph
nx.write_gpickle(G, "data/graph_data/marco_graph_pmi3_edges.gpickle")
# nx.draw(G, with_labels=True)
# plt.show()

print("Ended successfully")

import re
import os.path
from nltk.tokenize import sent_tokenize

# path to location of the datasets
CAR_TRECWEB_LOC = 'data/dedup.articles-paragraphs.cbor.xml'
# MARCO_TRECWEB_LOC='data/dedup.articles-paragraphs.cbor'
MARCO_TRECWEB_LOC = 'data/collection.tsv.xml'

cleanr = re.compile('<.*?>')


def process(loc, folder):
    with open(loc, 'r') as fp:
        line = fp.readline()
        id = ''
        cnt = 0
        while line:
            if "DOCNO" in line:
                id = re.sub(cleanr, '', line).replace('\n', '')
            if "<BODY>" in line:
                cnt += 1
                if cnt % 10000 == 0:
                    print(10)
                paragraph = fp.readline()
                if not os.path.isfile(folder + "/" + id + ".txt"):
                    with open(folder + "/" + id + ".txt", 'w') as out:
                        out.write(paragraph)
                        out.close()
            if cnt == 100000:
                break
            line = fp.readline()


# process(MARCO_TRECWEB_LOC, "data/marco_ids")
# process(CAR_TRECWEB_LOC, "data/car_ids")


def reformat(path):
    i = 0
    for root, dirs, files in os.walk(path):
        for file in files:
            add = []
            print(i)
            with open(path + file, 'r', encoding='UTF-8') as fp:
                print(file)
                # print('modifying ' + path + str(i) + '.txt')
                sentences = fp.readlines()
                for line in sentences:
                    add += list(filter(None, re.split('\.|\!|\?|\n|\:|\;', line)))
            with open(path + file, 'w') as fp:
                print(len(add), ': ', add)
                # for line in add:
                #     fp.write(line + '\n')
                fp.writelines(add)
            i += 1


# reformat("data/marco_ids/MARCO_")
# reformat("data/marco_ids/")
# reformat("data/marco_test/")
# reformat("data/car_ids/")
# with open('MARCO_1.txt', 'r') as mar:
#     for i in sent_tokenize(mar.read().replace('\n', '')):
#         print([i])
